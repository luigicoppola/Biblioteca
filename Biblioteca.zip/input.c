#include <stdio.h>
#include <stdlib.h>
#include "input.h"

void clearBuffer(){
    char c;
    while ((c = getchar()) != '\n' && c != EOF) { };
}



int getInt(int *data){
	int ok, // ritorno della funzione 
		i, // indice per scorrere la stringa letta
		negative; // indica se il numero � negativo
	char buffer[51];
	
	scanf("%50s",buffer);
	clearBuffer();
	
	i = negative = (buffer[0]=='-') ? 1 : 0 ;
	
	while( buffer[i]>47 && buffer[i]<58 ) i++;
	
	ok = (buffer[i]=='\0' && i>negative );
	
	if(ok) *data = atoi(buffer);
	
	return ok;
}

