#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "list.h"
#include "funzioni.h"

List inizializzaList(char titolo[100], int stato, int persona){
    List L = (List)malloc(sizeof(struct node));
    strcpy(L->titolo,titolo);
    L->stato=stato;
    L->persona=persona;
    L->next = NULL;
    return L;
}

List inCoda(List L, char titolo[100], int stato, int persona) {
    if (L != NULL) {
        L->next = inCoda(L->next, titolo, stato, persona);
    }
    else{
        L = inizializzaList(titolo,stato,persona);
    }
    return L;
}

List inTesta(List L, char titolo[100], int stato, int persona) {
    if (L != NULL) {
        List G = (List )malloc(sizeof(struct node));
        strcpy(G->titolo,titolo);
        G->stato=stato;
        G->persona=persona;
        G->next = L;
        return G;
    }
    return inizializzaList(titolo,stato,persona);
}

int lunghezza(List L,int n)
{
    
    if(L==NULL)
       return n;
    else{
       n=lunghezza(L->next,n+1);
       return n;}
}

void printList(List L) {
    if (L != NULL) {
        printf(" LIBRO:%s  --Stato:%d  --Preso da:%d\t\n ---------------------------------------------\n", L->titolo,L->stato,L->persona);
        printList(L->next);
    }
}


