#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "funzioni.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

menu();


	return 0;
}
