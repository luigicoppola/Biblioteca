#ifndef INPUT_H
#define INPUT_H

void clearBuffer();
int getInt(int *); //ritorna 1 se da input viene immesso un int

#endif
