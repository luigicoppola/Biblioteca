#ifndef LIST_H
#define LIST_H

struct node{
    char titolo[100];
    int stato;
    int persona;
    struct node* next;
};

typedef struct node* List;

List inizializzaList(char titolo[100], int stato, int persona);
List inCoda(List L, char titolo[100], int stato, int persona);
List inTesta(List L, char titolo[100], int stato, int persona);
int lunghezza(List L,int n);
void stampaList(List L);

#endif
