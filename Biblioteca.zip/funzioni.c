
#include <stdio.h>
#include <stdlib.h>
#include "list.h"



void inserisci_libri(List l)
{
//richiedo quanti libri si vogliono inserire, richiedendo titolo(titolo libro) ,stato (0 se libero, 1 se impegnato), persona (identificativo int >0);

    char titolo[100];
    int stato;
    int persona;
    int n,i;
        	printf("Quanti libri vuoi inserire:"); //chiedo quanti libri si vogliono inserire
        
        	while(!getInt(&n)||n<0) //controllo se � stato inserito un numero intero e se � un intero positivo.
			     printf("Scelta non valida. -- Inserisci scelta: ");
    				 for(i=0; i<n; i++){
        								printf("INSERISCI TITOLO DEL %d� LIBRO: \n",i+1);
        							    scanf("%s",titolo);
        								l=inCoda(l,titolo,1,0);
    									}	
    							    	
    							    
}



//stampa la lista dei libri
void visualizza_libreria(List l){
	printf("\n\nBIBLIOTECA ATTUALE (Libri): \n\n");
   	printList(l);
	
	
}




//ricerca libro con il titolo inserito da input
int ricerca(List l, char title[100])
{


if(l==NULL)
        return 0;
else{
	    if(strcmp(title,l->titolo)==0&&l->stato==1) //se i titoli sono uguali, e il libro � disponibile (stato=1) restituisci 1(disponibile)
	            return 1;                              
		            else return(ricerca(l->next,title));
    }
    
}











int ricerca_consegna(List l, char title[100],int matricola){

if(l==NULL)
        return 0;
else{
	    if(strcmp(title,l->titolo)==0&&l->persona==matricola)
	            return 1;
		            else return(ricerca_consegna(l->next,title,matricola));
    }	
	
}


void Dealloca(List *s){
List p,c;
p=*s;
while(p){
c=p->next;
free(p);
p=c;
}
*s=NULL;
}






List elimina_elemento(List s,char title[100]){
  
    if(s!=NULL){
       s->next=elimina_elemento(s->next,title);
       if (strcmp(title,s->titolo)==0) {
            List tmp = s->next;
            free(s);
            return tmp;
        }
    }
    return s;
}




int ricerca_rivaluta(List s, char title[100]){

if(s==NULL)
        return 0;
else{
	    if(strcmp(title,s->titolo)==0){
	    	printf("STAMPA :");
	    	printf("Titolo: %s --- Stato: %d --- Matricola: %d",s->titolo,s->stato,s->persona);
	    	
	    
	   
		    return 1;
		      }
			        else return(ricerca_rivaluta(s->next,title));
    }	
	
}




	
void modifica_inlista(List l,char title[100],int matricola_richiesta){
	
   while(l!=NULL){
   	
   			if(strcmp(title,l->titolo)==0&&l->stato==1)
   																{
   																	l->stato=0;
   																//	printf("MATRICOLA VALE: %d",matricola_richiesta);
   																	l->persona=matricola_richiesta;
																   }
   	
   	
   	l=l->next;
   }
}




modifica_inlista_riconsegna(List l,char title[100],int matricola){
	
   while(l!=NULL){
   	
   			if(strcmp(title,l->titolo)==0&&l->persona==matricola)
   																{
   																	l->stato=1;
   																	l->persona=0;
																   }
   	
   	   	l=l->next;
   }
}


//prendo title riconsegnato
//risalgo alla prima richiesta per questo titolo
//riformulo richiesta con nuovi accessi


/*


List elimina_elemento(List s, char title[100], int matricola)
{
if(!s) 
return NULL;
if(s->titolo ==title&&s->persona==matricola);
{
List tmp = s->next;
free(s);
return tmp;
}
s->next = eliminaelemento(s->next, title, matricola);
return s;
}

/*
void controllo_titolo_consegnato_in_sospese(List l, List s, char title[100]){

   

   //scorro la lista s.
   //se s->titolo==l->libri && l->stato==1
   //stampo a video il messaggio: Attenzione---> ATTENZIONE: UNA RICHIESTA SOSPESA HA AVUTO ESITO POSITIVO POICHE' IL LIBRO RICHIESTO E' TORNATO DISPONIBILE.
     //PUOI VISUALIZZARE I DETTAGLI A CHIUSURA NEGOZIO
     
  // allora l->stato=0 ed l->persona=s->matricola
  //cancella richiesta dalla lista s.
  

	
     while(l!=NULL){
   	
   			if(strcmp(title,s->titolo)==0&&s->stato==1)
   																{
   																 printf("ATTENZIONE! QUESTA RICONSEGNA HA DATO ESITO POSITIVO AD UNA RICHIESTA SOSPESA PER INDISPONIBILITA' LIBRO.\n POTRAI VISUALIZZARE IL RIEPILOGO A CHIUSURA NEGOZIO.\n");
																 l->stato=0;
																 l->persona=s->matricola;
																 elimina_elemento(s,s->titolo,s->matricola);
																 printList(s);
																  }
   	
   	   	l=l->next; 
	
	
	
}
 	
 	
 	
 	
 	
 	
 	
 }
 
 

*/






int prova_controllo(List s, char title[100]){
	int trovato=0;
while(s!=NULL){
	
if(strcmp(title,s->titolo)==0)
   trovato=1;
	
s=s->next;	
}
	
return trovato;	
	
}









void menu(){
int esci=0;
	int esci4=0;
	int n,i;
   
   List l=NULL;
    int scelta,scelta2,scelta3;
    
    // inserisco i 15 libri in una lista l
    l=inCoda(l,"algebrando",1,0);
    l=inCoda(l,"chimicando",1,0);
    l=inCoda(l,"matematicamente",1,0);
    l=inCoda(l,"scienza",1,0);
    l=inCoda(l,"languages",1,0);
    l=inCoda(l,"manuale",0,11);
    l=inCoda(l,"marketing",0,3030);
    l=inCoda(l,"linguaggi",1,0);
    l=inCoda(l,"programmazione",1,0);
    l=inCoda(l,"logica",0,5151);
    l=inCoda(l,"statisticando",1,0);
    l=inCoda(l,"quiz",1,0);
    l=inCoda(l,"paper",1,0);
    l=inCoda(l,"mistero",0,1212);
    l=inCoda(l,"sapere",0,2323);
     
    

    printf("====================================================");
    printf("\n");
    printf("  BUONGIORNO, INIZIAMO QUESTA GIORNATA DI LAVORO!");
    printf("\n");
    printf("====================================================");
     
     
    while(!esci){
	
	
	printf("\n Puoi:\n\n [1] Visualizzare i libri gia' presenti.\n [2] Inserire altri libri.\n\n --Inserisci Scelta [1] o [2]: ");
    	while(!getInt(&scelta)||scelta<=0||scelta>2) {
		                                            printf("\n Scelta errata. -- Inserisci la scelta corretta [1] o [2]: ");
											       }
    
    
    
      	switch(scelta){
      		 
			   case 1:	 printf("\n\nBIBLIOTECA ATTUALE (Libri): \n\n");
			          
			         
   								 visualizza_libreria(l);
   								 
   								 
                             	 printf("\nMANCA POCO TEMPO ALLE ORE 10:00!\n");
                             	       
								 	       	          printf("Vuoi inserire altri libri?\n [1]SI\n [2]NO\n --Inserisci scelta [1] o [2]: ");
                                 	     	          	while(!getInt(&scelta2)||scelta2<=0||scelta2>3) {
		                                                                                         printf("\n Scelta errata. -- Inserisci la scelta corretta [1] o [2]: ");
											                                                       }
                                    
									switch(scelta2){
			        								case 1: inserisci_libri(l); //inserisco altri libri alla libreria gi� presente
                    								        visualizza_libreria(l); //stampo tutti i libri presenti con i suoi tre valori
   												            printf("\nSONO LE ORE 10:00! NON PUOI INSERIRE PIU' LIBRI!\n");
   												             //avvia men� richieste studenti
   												             esci=1;
   												            
   												            break;
					              				 
					              				  
					              		
					              					case 2: //visualizzo i libri gi� presenti
			        								     	visualizza_libreria(l);
    												        printf("\nSONO LE ORE 10:00! NON PUOI INSERIRE PIU' LIBRI!\n");
                   									        //avvia men� richieste studenti
                   									        esci=1;
                   									        break;
                   									    
                   								    
                   											         													
                   									    }
					              				  
					        
					              	 break;
                                   
                          
        	   case 2:		inserisci_libri(l); //richiede nuovamente se vuoi inserire libri da input
                 			printf("MANCA POCO TEMPO ALLE ORE 10:00! Vuoi inserire altri libri?\n [1]SI\n [2]NO: ");
                   			scanf("%d",&scelta3);
                   			if(scelta3==1){ //se si,
                   			inserisci_libri(l); //inserisco i libri
                    		printf("\n\nBIBLIOTECA ATTUALE (Libri): \n\n");
    						visualizza_libreria(l); //stampa i libri presenti con i suoi 3 valori
    					}
    						printf("\nSONO LE ORE 10:00! NON PUOI INSERIRE PIU' LIBRI!\n\n");
                    		 //avvia men� richieste studenti
                    		 
             				break;
             				
             				
                	
                   									        
	         													
	                }
	                    
	                    
	                    
	              
	                    
	                }
	                 
                        //do-while (ripeti il men� se inserisci da input numeri diversi da 1 e 2 che sono le uniche scelte disponibili
				   
int scelta4;
char title[100];
int matricola;
int esito;
int esci2=0;
List s=NULL;
int trovato;
int matricola_richiesta;
int conta_richieste_prestito_tutte=0; //conto richieste prestito effettuate tutte.
int conta_prestito_soddisfatte=0;     //conto le richieste prestito soddisfatte subito
int conta_prestito_sospeso_tutte=0; //conta tutte le richieste prestito in sospeso
int conta_prestito_rifiutato_subito=0;  //conta richieste prestito rifiutate subito
int conta_riconsegne_tutte=0; //conta tutte le riconsegne
int conta_consegne_errate=0;  //conta le consegne errate
int conta_riconsegne_positive=0; //conta le riconsegne positive 





printf("===============================================================================");
//printf("\n");
printf("\n\nBIBLIOTECA APERTA UFFICIALMENTE ALLE RICHIESTE DEGLI STUDENTI\n\n") ;
//printf("\n");
printf("===============================================================================");



while(!esci2){


printf("\n\n Adesso puoi effettuare le seguenti operazioni di inserimento:\n\n [1]RICHIESTA PRESTITO.\n [2]RICONSEGNA LIBRO.\n [3]VISUALIZZA BIBLIOTECA.\n [4]VISUALIZZA RICHIESTE SOSPESE\n [5]CHIUDI AL PUBBLICO --Inserisci la tua scelta [1][2][3]: ");
    	while(!getInt(&scelta4)||scelta4<=0||scelta4>5) {
		                                            printf("\n Scelta errata. -- Inserisci la scelta corretta [1] o [2]: ");
											       }
    
    
    switch(scelta4){
      		 
			         	case 1: conta_richieste_prestito_tutte++; //conto quante richieste vengo effettuate in un giorno
						        printf("Inserire titolo libro richiesto: "); 
			         	        scanf("%s",title); //richiedo il titolo.
			         	         //ricerca libro
			         	         int esito=ricerca(l,title); //verifico se il titolo inserito � presente nella biblioteca
			         	         //printf("\nESITO: %d",esito);
			         	        if(esito==1){   //se l'esito � 0, allora libro disponibile, richiedo la matricola allo studente
								 				printf("Il libro e' disponibile.\n");
								 				
								 			//controllo che la matricola sia un numero intero >1000.
								 			
								 			printf("Inserisci matricola: ");
								 			while(!getInt(&matricola)||matricola<1000) {
								 				                                         printf("Formato matricola errato. -- Inserisci la matricola corretta: ");
											                                            }
								 				modifica_inlista(l,title,matricola); //modifico i dati di quel libro con la matricola del nuovo studente
			         	        				printf("\n-------- * RICHIESTA SODDISFATTA CORRETTAMENTE!*--------\n"); 
			         	        				conta_prestito_soddisfatte; //conto le richieste soddisfatte
			         	        				//visualizza_libreria(l); //stampo la libreria con i nuovi dati
			         	        			}
			         	        			
					  	        if(esito==0){
					  	        	
					  	        	int p=prova_controllo(s,title); //controllo se c'� gi� una richiesta sospesa per quel libro
					  	        	
					  	        	
					  	        		if(p==0){ //se non c'� gi� una richiesta per quel libro scelto, segnalo che la richiesta � sospesa e richiedo la matrica dello studente
			         	        				
			         	        				printf("\n-----\n LIBRO MOMENTANEAMENTE NON DISPONIBILE -> RICHIESTA SOSPESA. \n VERRA' RIVALUTATA SE IL LIBRO TORNERA' DISPONIBILE.\n-----\n");
			         	     					
												
			         	         					printf("\nInserisci matricola dello studente: "); 
			         	         					while(!getInt(&matricola_richiesta)||matricola_richiesta<1000) {
								 																printf("Formato matricola errato. -- Inserisci la matricola corretta: ");
											       											   }
			         	        				s=inCoda(s,title,0,matricola_richiesta);//inserisco la richiesta sospesa nella lista richieste sospese.
			         	       					conta_prestito_sospeso_tutte++; //conto quante richieste sospese ho
			         	       				 	printf("\n\nELENCO RICHIESTE SOSPESE: \n\n");
   	                                 			printList(s); //visualizzo la lista di richieste sospese
   	                                 	
			         	        				
			         	        			     }
			         	        			
   	                                 	    if(p==1){ //se c'� gi� una richiesta sospesa per quel libro, allora comunico subito il rifiuto e non la inserisco nelle sospese.
													  
   	                                 	      	printf("\n\n----- ESISTE UN'ALTRA RICHIESTA SOSPESA PER IL LIBRO RICHIESTO.\n RICHIESTA DEFINITIVAMENTE RIFIUTATA.\n\n-----");
   	                                 	      	conta_prestito_rifiutato_subito++;
												printList(s); //quindi ristampo la situazione della biblioteca
   	                                 	      }
   	                                 	    }
												break;
			         	       
			         	case 2: conta_riconsegne_tutte++; //conto le riconsegne
						        printf("Inserire titolo libro riconsegnato: "); //richiedo i dati della riconsegna
			         	        scanf("%s",title);
			         	        			
			         	         				printf("\nInserisci matricola dello studente: "); 
			         	         				while(!getInt(&matricola)||matricola<1000) 
												  {
								 				     printf("Formato matricola errato. -- Inserisci la matricola corretta: ");
											      }
			         	        //controllo se esiste realmente il prestito del libro con questi dati
			         	        int ric=ricerca_consegna(l,title,matricola);
			         	        if(ric==0){ //se non trova il prestito con queste info, segnala l'errore, conta le consegne errate e fa ripartire il men� di scelta.
								// printf("\nRIC VALE 0\n");
			          	        				printf("\n-----NON ESISTE NESSUN PRESTITO CON QUESTE INFORMAZIONI INSERITE.-----\n");
			          	        				conta_consegne_errate++;
			          	             	  }  
										
										   
			         	        if(ric==1){ //se il prestito esiste
								 //printf("\nRIC VALE 1\n");
								          	modifica_inlista_riconsegna(l,title,0); //torna disponibile il libro nella biblioteca (status=0,matricola=0)
			         	        			printf("\n-----RICONSEGNA AVVENUTA CON SUCCESSO-----");
			         	        			conta_riconsegne_positive++;
			         	        //visualizza_libreria(l); //visualizzo la situazione della libreria
			         	        
			         	       //vedo se questa riconsegna soddisfa una richiesta sospesa.
			         	        trovato=ricerca_rivaluta(s,title);  //ricerco il titolo del libro riconsegnato nella lista dei titoli delle richieste sospese
			         	      //  printf("\nTrovato vale %d\n",trovato);
			         	        
			         	        if(trovato==1){ //se trovo la corrispondenza dei titoli, segnalo che la richiesta sospesa � stata soddisfatta positivamente
								 
			         	       				 printf("\n-----ATTENZIONE, QUESTA RICONSEGNA HA SODDISFATTO UNA RICHIESTA SOSPESA-----");
			         	        			 modifica_inlista(l,title,matricola_richiesta); //quindi inserisco matricola del richiedente e stato=0 al libro richiesto
			         	        //visualizza_libreria(l); 
			         	                     s=elimina_elemento(s,title);
			         	                     conta_prestito_soddisfatte++; //aggiungo la conta alle richieste sospese soddisfatte
			         	                     conta_prestito_sospeso_tutte--;  //diminuisco quindi la conta delle richieste sospese
			         	        	         printf("\n\n");
			         	           }
			         	    }
			         	        break;
			         	 
						case 3: visualizza_libreria(l);
						        break;
						        
						case 4: if(s==NULL)
						        printf("\n---NON CI SONO RICHIESTE SOSPESE.---\n");
						        else
						        printf("\nELENCO RICHIESTE SOSPESE:\n");
						        printList(s);
						        break; 
			         	    
			         	case 5: esci2=1;	   //chiudo al pubblico, termino di ricevere richieste e riconsegne      	        
			         		    break;
			         		
			         	
			         
			         	
			         	
			        
			         }
			         	
			}

   
    
    int scelta5;
    int lenght;
    
    
printf("==============================================================");
printf("\n");
    printf("\n SONO LE ORE 16:00. CHIUSURA AL PUBBLICO ATTIVATA.\n");
printf("\n");   
printf("==============================================================");

    
    //faccio un riepilogo della giornata
    /*printf("\nOggi hai ricevuto %d richieste e %d riconsegne\n",conta_richieste,conta_consegne);
    printf("Hai %d richieste sospese.\n",conta_sospese_prima);*/
    
    int esci3=0;
    
    while(!esci3)
	{
		printf("\nAdesso puoi:\n\n[1]Visualizzare le richieste in sospeso.\n[2]Invio esito negativo alle richieste sospese.\n[3]Termina la giornata di lavoro.\n");
		printf("--Inserisci scelta [1] o [2] o [3]: ");
			while(!getInt(&scelta5)||scelta5<=0||scelta>3) {
		                                            printf("\n Scelta errata. -- Inserisci la scelta corretta [1] o [2]: ");
											       }
			         	        
		switch(scelta5){
			             case 1: if(s==NULL) //se la lista di richieste sospese � NULL, allora non ci sono richieste sospese e possiamo chiudere il negozio.
			                         printf("\nNON CI SONO RICHIESTA SOSPESE. SONO LE ORE 18:00. SI CHIUDE, A DOMANI!\n");
			                     else //altrimenti segnalo che ci sono richieste sospese con esito negativo da comunicare e ne stampo i dettagli.
			                             lenght=lunghezza(s,0);
								        printf("\nCI SONO LE SEGUENTI %d RICHIESTE SOSPESE CON ESITO NEGATIVO.\n",lenght);
								       printList(s);
			                             break;
			             
			             case 2: printf("RICHIESTE SOSPESE CON ESITO NEGATIVO:");
			             		 printList(s);
			             		 printf("\n---COMUNICAZIONE ESITO NEGATIVO EFFETTUATA---\n");
			             		 Dealloca(&s);
			             		 break;
								  	                       
			             case 3: if(s==NULL){ //se ho inviato a tutti le email allora posso terminare la giornata lavorativa
							     printf("\nTutte le richieste di oggi hanno avuto esiti.\n");
							      printf("\n TOTALE RICHIESTE PRESTITO: %d, di cui:",conta_richieste_prestito_tutte);
			                     printf("\n  --Richieste accettate: %d\n --Richieste respinte %d.",conta_prestito_soddisfatte,conta_prestito_rifiutato_subito);
			                     printf("\n  --Richieste sospese con esito positivo: %d\n Richieste sospese con esito negativo: %d.",conta_prestito_soddisfatte,lenght);
			                      printf("\n\n TOTALE RICONSEGNE: %d, di cui:",conta_riconsegne_tutte);
								 printf("\n  --Richieste di riconsegna con esito positivo: %d.\n  --Richieste di riconsegna con esito negativo: %d.\n",conta_riconsegne_positive,conta_consegne_errate);
								 printf("\n\n SONO LE ORE 18:00. SI CHIUDE, A DOMANI!");
			                     esci3=1;
			                      }
			                      else //altrimenti se ho ancora richieste sospese senza aver comunicato l'esito negativo agli studenti, non posso chiudere il negozio-
			                      printf("\nNON PUOI ANCORA CHIUDERE LA GIORNATA PERCHE' DEVI COMUNICARE GLI ESITI NEGATIVI DI %d RICHIESTE SOSPESE.\n",lenght);
			
			

			         	        	
			           }
			         	        
			         	        
                                 }
    

}
