
void menu();
void inserisci_libri(List l);
void visualizza_libreria(List l);
int ricerca(List l, char title[100]);
int ricerca_consegna(List l, char title[100],int matricola);
void Dealloca(List *s);
List elimina_elemento(List s,char title[100]);
int ricerca_rivaluta(List s, char title[100]);
void modifica_inlista(List l,char title[100],int matricola_richiesta);
void modifica_inlista_riconsegna(List l,char title[100],int matricola);
int prova_controllo(List s, char title[100]);
